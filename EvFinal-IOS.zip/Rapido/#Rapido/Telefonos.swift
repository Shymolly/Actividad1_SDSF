import Foundation
import UIKit

struct Telefonos {
    
    var telefono : String
    
    static var listTelefonos : [Telefonos] = [
        
        Telefonos.init(telefono: "10/10"),
        Telefonos.init(telefono: "0/10")
    
    ]
    
}


