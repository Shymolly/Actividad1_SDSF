import UIKit
import CoreData

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var negocios : [Negocio] = []
    
    @IBOutlet weak var nombreTextField: UITextField!
    
    @IBOutlet weak var telefonoTextField: UITextField!
    
    @IBOutlet weak var direccionTextField: UITextField!
    
    // @IBOutlet weak var imageContacto: UIImageView!
    
    
    @IBOutlet weak var botonRedondo: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        botonRedondo.layer.cornerRadius = 10.0
        botonRedondo.layer.masksToBounds = true
        
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:)))
        
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
        
        recoverData()
        
    }

    @IBAction func agregarBoton(_ sender: UIButton) {
        
        guard let nombre = nombreTextField.text, let telefono = telefonoTextField.text, let direccion = direccionTextField.text else {
            return
        }
        save(nombre: nombre, telefono: Int(telefono)!, direccion: direccion)
        performSegue(withIdentifier: "unwindToMenu", sender: self)
        
    }
    

    func connection() -> NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }
    
    func recoverData(){
        
        let context = connection()
        let fetchRequest : NSFetchRequest<Negocio> = Negocio.fetchRequest()
        
        do {
            negocios = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print("Error al recuperar los datos.", error)
        }
    }
    
    func save(nombre: String, telefono: Int, direccion : String) {
        let context = connection()
        let entityNegocio = NSEntityDescription.entity(forEntityName: "Negocio", in: context)!
        
        let negocio = NSManagedObject(entity: entityNegocio, insertInto: context)
        negocio.setValue(nombre, forKeyPath: "nombre")
        negocio.setValue(telefono, forKey: "calificacion")
        negocio.setValue(direccion, forKey: "opinion")
        
        do {
            try context.save()
        } catch let error as NSError {
            print("Error al guardar. \(error), \(error.userInfo)")
        }
    }
    
}

