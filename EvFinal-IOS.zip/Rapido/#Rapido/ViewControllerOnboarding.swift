import UIKit

class ViewControllerOnboarding: UIViewController {

    @IBOutlet weak var botonOnboardingRedondo: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        botonOnboardingRedondo.layer.cornerRadius = 7.0
        botonOnboardingRedondo.layer.masksToBounds = true
    }
    

    
    @IBAction func showEscenaDirectorio(_ sender: UIButton) {
        
        
        UserDefaults.standard.set(true, forKey: "session")
        
    }
    

}
