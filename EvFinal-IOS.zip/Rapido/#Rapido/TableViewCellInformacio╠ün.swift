import UIKit

class TableViewCellInformacio_n: UITableViewCell {
    
    
    @IBOutlet weak var labelNombre: UILabel!
    
    
    @IBOutlet weak var labelNumero: UILabel!
    
    @IBOutlet weak var labelDireccion: UILabel!
    
    
    @IBOutlet weak var imageFoto: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
