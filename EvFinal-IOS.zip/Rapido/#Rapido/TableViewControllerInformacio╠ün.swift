import UIKit
import CoreData

struct Directorio {
    
    var image : UIImage
    var nombre : String
    var numero : String
    var direccion : String
    
}

class TableViewControllerInformacio_n: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var directorio : [Directorio] = [Directorio]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        directorio.append(Directorio.init(image: UIImage.init(named: "Pelicula")!, nombre: "Transformers", numero: "8/10", direccion: "tiene buena historia pero mala animacion"))
        
        directorio.append(Directorio.init(image: UIImage.init(named: "Serie")!, nombre: "Steven universe", numero: "10/10", direccion: "La mejor serie que eh visto"))
        
        directorio.append(Directorio.init(image: UIImage.init(named: "Serie")!, nombre: "Naruto", numero: "8/10", direccion: "Buena historia pero mucho relleno"))
        
        directorio.append(Directorio.init(image: UIImage.init(named: "Serie")!, nombre: "Citrus", numero: "9/10", direccion: "El mejor yuri espero saquen mas temporadas"))
        
        directorio.append(Directorio.init(image: UIImage.init(named: "Pelicula")!, nombre: "Avatar", numero: "10/10", direccion: "ahora es mi pelicula fav"))
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return directorio.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Informacion", for: indexPath) as? TableViewCellInformacio_n
        
        let direccciones = directorio[indexPath.row]
        
        cell?.labelNombre.text = direccciones.nombre
        cell?.labelNumero.text = direccciones.numero
        cell?.labelDireccion.text = direccciones.direccion
        cell?.imageFoto.image = direccciones.image
        
        return cell!
        
    }
    
    
    @IBAction func agregarFoto(_ sender: Any) {
        
        
        let imagePickerController = UIImagePickerController()
        
        imagePickerController.delegate = self
        
        let actionSheet = UIAlertController(title: "De donde quieras escoger", message: "selecciona bien", preferredStyle: .actionSheet)
        
        actionSheet.addAction(UIAlertAction(title: "Cámara", style: .default, handler: {(action: UIAlertAction)
            in
            
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                
                imagePickerController.sourceType = .camera
                
                self.present(imagePickerController, animated: true, completion: nil)
                
            } else {
                
                print("Cámara no disponible")
            }
            
            
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Galerìa de fotos", style: .default, handler: {(action: UIAlertAction)
            in
            
            imagePickerController.sourceType = .photoLibrary
            
            self.present(imagePickerController, animated: true, completion: nil)
            
            
        }))
        
        actionSheet.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        
        
        self.present(actionSheet, animated: true, completion: nil)
      
    }
    
    //Funciones del ImagePicker Controller
    func imagePickerController(_ _picker: UIImagePickerController, didFinishPickingMediaWithInfo info  : [UIImagePickerController.InfoKey : Any]) {
        
        let imageTaked = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        
        //imageFoto.image = imageTaked
        dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    
    @IBAction func guadarFoto(_ sender: UIButton) {
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let imageEntity = NSEntityDescription.entity(forEntityName: "Image", in: context)
        let newImage = NSManagedObject(entity: imageEntity!, insertInto: context)
        
        do {
            
            try context.save()
            //alert print label
        } catch _ as NSError {
            
            print("Que pasoooo???")
            
            
        }
        
        
    }

}
