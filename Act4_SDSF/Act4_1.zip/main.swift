
var Num: [Int] = [3,6,9,2,4,1];
var count = 0;
for dato in Num{
  if dato<5{
    print(dato, "es menor que 5")
    count+=1
  }else{
    print(dato, "es mayor que 5")
  }
}
print(count, "numeros son menores a 5")

