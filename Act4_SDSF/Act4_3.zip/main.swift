enum meses{
    case Enero 
    case Febrero
    case Marzo
    case Abril
    case Mayo
    case Junio
    case Julio
    case Agosto
    case Septiembre
    case Octubre
    case Noviembre
    case Diciembre
}
func numeroMes (mes:meses)->Int{
    switch meses{
      case .Enero: 
        print("Enero mes 1")
      case .Febrero: 
        print("Febrero mes 2")
      case .Marzo: 
        print("Marzo mes 3")
      case .Abril: 
        print("Abril mes 4") 
      case .Mayo: 
        print("Mayo mes 5")
      case .Junio: 
        print("Junio mes 6")
      case .Julio:
        print("Julio mes 7")
      case .Agosto: 
        print("Agosto mes 8")
      case .Septiembre: 
        print("Septiembre mes 9")
      case .Octubre: 
        print("Octubre mes 10")
      case .Noviembre: 
        print("Noviembre mes 11")
      case .Diciembre: 
        print("Diciembre mes 12")
      default:
        print ("Ya no hay mas meses") 
    }
    return resultado
} 
print (resultado)













/*case 1: 
        print("Enero mes 1")
      case 2: 
        print("Febrero mes 2")
      case 3: 
        print("Marzo mes 3")
      case 4: 
        print("Abril mes 4") 
      case 5: 
        print("Mayo mes 5")
      case 6: 
        print("Junio mes 6")
      case 7: 
        print("Julio mes 7")
      case 8: 
        print("Agosto mes 8")
      case 9: 
        print("Septiembre mes 9")
      case 10: 
        print("Octubre mes 10")
      case 11: 
        print("Noviembre mes 11")
      case 12: 
        print("Diciembre mes 12")
      default:
        print ("Ya no hay mas meses") 

        case .Enero: resultado = 1
        case .Febrero: resultado = 2
        case .Marzo: resultado = 3
        case .Abril: resultado = 4
        case .Mayo: resultado=5
        case .Junio: resultado=6
        case .Julio: resultado=7
        case .Agosto: resultado=8
        case .Septiembre: resultado=9
        case .Octubre: resultado=10
        case .Noviembre: resultado=11
        case .Diciembre: resultado=12
        default:
          print ("Ya no hay mas meses") */

/*let meses = 3

switch meses {
  case 1: 
    print("Enero mes 1")
  case 2: 
    print("Febrero mes 2")
  case 3: 
    print("Marzo mes 3")
  case 4: 
    print("Abril mes 4") 
  case 5: 
    print("Mayo mes 5")
  case 6: 
    print("Junio mes 6")
  case 7: 
    print("Julio mes 7")
  case 8: 
    print("Agpsto mes 8")
  case 9: 
    print("Septiembre mes 9")
  case 10: 
    print("Octubre mes 10")
  case 11: 
    print("Noviembre mes 11")
  case 12: 
    print("Diciembre mes 12")
  default:
    print ("Ya no hay mas meses") 
}*/

   
