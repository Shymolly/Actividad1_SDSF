
func suma (a:Int, b:Int) -> Int{
  let res1 = a + b
  return res1
}

func potencia (c:Int, d:Int) -> Int{
  let res2 = c + d
  return res2
}

let res1 = suma (a: 1, b: 2)
let res2 = potencia (c: 7, d: 2)

var resultado = res1
for index in 1...res2 {
  resultado = resultado * res1
}

print ("El resultado de elevar", res1, "a la", res2, "potencia es igual a:", resultado)


