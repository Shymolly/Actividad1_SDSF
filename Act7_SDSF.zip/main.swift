/*Luego de crear el proyecto, resuelve lo siguiente para el tema relacionado con el valor por tipo y por referencia:
2.	Para la colección var costo_referencia:[Float] = [8.3,10.5,9.9], aplica el impuesto del 16% a través de recorrer la colección costo_referencia para aplicar el impuesto a cada cantidad.
3.	Crea una función impuesto que reciba como parámetro la colección y regrese aplicado el impuesto a cada cantidad.
4.	Crea la función sumaTres que reciba una función con dos valores a sumar y un segundo parámetro para sumar el tercer número.*/

var costo_referencia:[Float] = [8.3,10.5,9.9]
var impuesto_aplicar = [Float] ();
var impuesto_aplicado = [Float] ();
func impuesto (){
  for dato in costo_referencia{
    print("La cantidad sin impuesto es", dato)
    let i = dato*0.16
    impuesto_aplicar.append(i)
    print("El impuesto a aplicar es", i)
    let j = dato+i
    print("El impuesto aplicado es", j)
    impuesto_aplicado.append(j)
  }
}

func sumaTres (a:Int, b:Int, c:Int) -> Int{
  let suma = a+b+c
  print("El resultado de la suma es",suma)
  return suma
}
impuesto()
sumaTres(a: 4, b: 6, c:767)

/* Para funciones personalizadas y genéricos, desarrolla los siguientes planteamientos:
5.	Crea una función genérica para intercambiar valores entre dos variables del mismo tipo.
6.	Crea la función Transformar que reciba como parámetro una colección de tipo Int var datos = [3,7,9,2] y una función que transforme cada valor de la colección en una operación definida fuera de la función, regresando una colección transformada.*/

func Transformar (e:Int){
  var datos = [3,7,9,2] 
  var datos_transformados = [Int] ();
  for index in datos{
    print("Dato sin transformar", index)
    let d = e+index
    datos_transformados.append(d)
    print("Dato transformado", d)
  }
}
Transformar(e:77)

/*Luego desarrolla lo siguiente:
7.	Aplica la función de librería de Swift map para la colección var precios = [4.2, 5.3, 8.2, 4.5] y aplica el impuesto de 16% y asígnala a la variable impuesto.
8.	Aplica la función de la librería de Swift filter para la colección resultante impuesto del paso A, en donde obtengas sólo los precios mayores a 6.0 y asígnalos a la variable precio_menor.*/

var libreria:[Float] = [4.2, 5.3, 8.2, 4.5]
var impuesto_aplicar1 = [Float] ();
var impuesto_aplicado1 = [Float] ();
var precio_menor = [Float] ();
var precio_mayor = [Float] ();
func impuesto1 (){
  for f in libreria{
    print("La cantidad sin impuesto es", f)
    let g = f*0.16
    impuesto_aplicar1.append(g)
    print("El impuesto a aplicar es", g)
    let h = f+g
    print("El impuesto aplicado es", h)
    impuesto_aplicado1.append(h)
    if h < 6{
      precio_menor.append(h)
    }else{
      precio_mayor.append(h)
    }
  }
}
impuesto1()
print ("los precios menores a 6 son:", precio_menor)
print ("los precios mayores a 6 son:", precio_mayor)
