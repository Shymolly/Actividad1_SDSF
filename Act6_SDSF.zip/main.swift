/*:
# Playground - Actividad 6
* Operadores personalizados
* Subscripts
* Control de errores
*/

/*: 
### Operadores personalizados
A) Crear el operador para realizar la potencia de el valor "a" a la potencia "b" en valores enteros
*/

var a=2;
var b=4;

for index in 1...b{
  a=a*b
}
print("A elevado a la potencia B es igual a:",a)

//: B) Crear el operador |> para ordenar la colección [2,5,3,4] de menor a mayor

infix operator |>
fun |> (d: Int, f: (Int)-> Int) ->Int{
  return f(d)
}
var Num:[Int] = [2,5,3,4];
for dato in Num{
  var c=dato+1
  if dato < c{
    print(dato)
  }
}

/*:
### Subscripts
A) Del conjunto de datos en el Array [2,3,4,5], crear el subscript para modificar los valores multiplicados por el valor 2 y extraer al valor dado un índice.
*/

subscript (index:Int) -> Int{
  return 2*index
}

//: B) Crear el Struct para definir u obtener la posición  para los personaje de tipo Enemigo donde cada posición es de tipo CGPoint aplicanado subscritps
struct enemigo{
  subscript (i:Int) -> Int{
    get{
      return Num[i]
    }
  }
}
/*:
### Control de Errores
A) Crear la función ExisteValor en la cual se reciba como parámetro el valor a buscar dentro de un colección ["A":1, "B":2,"C":3]
*/

let dicterror = ["A":1, "B":2,"C":3]
func existe (idx:Int){
  guard let existe = dicterror[idx] else {
     print("No existe")
     return
    }
    print("existe",existe)
}

